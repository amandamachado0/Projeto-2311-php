<?php //pagina inicial

namespace App\Controllers;

use App\Models\PostModel;

class Home extends BaseController
{
    public function index(): string
    {
        $postModel = new PostModel();

        // recebe o texto digitado na pesquisa
        $pesquisa = $this->request->getGet('pesquisa');

        if (!empty($pesquisa)) {

            $posts = $postModel
                ->like('titulo', $pesquisa)
                ->orderBy('id', 'DESC')
                ->findAll();

        } else {

            $posts = $postModel
                ->orderBy('id', 'DESC')
                ->findAll(6);

        }

        return view('home', [
            'posts' => $posts,
            'pesquisa' => $pesquisa
        ]);  //enviar para pagina home
    }

     //todas cadastradas
    public function receitas(): string
    {
        $postModel = new PostModel();

        $posts = $postModel
            ->orderBy('id', 'DESC')
            ->findAll();

        return view('receitas', [
            'posts' => $posts
        ]);
    }
}
