<?php //gerenciamento das receitas

namespace App\Controllers;

use App\Controllers\BaseController;

class Posts extends BaseController
{
    public function index()
    {
        $postModel = model('PostModel');

        // recuperar as receitas cadastradas na tabela
        $pesquisa = $this->request->getGet('pesquisa');

        // verifica se foi feita uma pesquisa
        if (!empty($pesquisa)) {
            $dados['posts'] = $postModel
                ->like('titulo', $pesquisa)
                ->orderBy('id', 'DESC')
                ->findAll();
        } else {

            $dados['posts'] = $postModel
                ->orderBy('id', 'DESC')
                ->findAll();
        }

        $dados['pesquisa'] = $pesquisa;

        return view('post', $dados); // para a view
    }

    public function inserir()
    {
        $dados['msg'] = "";

        // verifica se foi feita uma requisição POST
        if ($this->request->is('post')) {
            $postModel = model('PostModel');
            $dadosPost = $this->request->getPost();

            // recebe a imagem do formulário
            $imagem = $this->request->getFile('imagem');

            if ($imagem && $imagem->getError() != UPLOAD_ERR_NO_FILE) {

                // validacao da imagem
                if (!$imagem->isValid()) {
                    $dados['msg'] = "Erro ao enviar imagem";
                    return view('post_form', $dados);
                }

               
                if (!in_array($imagem->getMimeType(), ['image/jpeg', 'image/png', 'image/gif', 'image/webp']) || $imagem->getSize() > 2097152) {
                    $dados['msg'] = "Imagem inválida ou grande demais!!";
                    return view('post_form', $dados);  //formato e o tamanho da imagem
                } 

                // salva a imagem na pasta
                $nomeImagem = $imagem->getRandomName();
                $imagem->move(FCPATH . 'uploads/receitas', $nomeImagem);

                $dadosPost['imagem'] = $nomeImagem;
            }




            if ($postModel->insert($dadosPost)) {
                // sucesso
                return redirect()->to('painel/posts');
            } else {
                // erro
                $dados['msg'] = "Erro ao salvar receita";
            }
        }

        return view('post_form', $dados);
    }

    
    public function editar($id)
    {
        $postModel = model('PostModel');
        $dados['post'] = $postModel->find($id);
        $dados['msg'] = '';

        if (!$dados['post']) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        //requisição POST
        if ($this->request->is('post')) {
            $dadosPost = $this->request->getPost();

            // recebe uma nova imagem, caso tenha sido selecionada
            $imagem = $this->request->getFile('imagem');

            if ($imagem && $imagem->getError() != UPLOAD_ERR_NO_FILE) {

                // verifica se a imagem é válida
                if (!$imagem->isValid()) {
                    $dados['msg'] = "Erro ao enviar imagem";
                    return view('post_form', $dados);
                }

                // verifica o formato e o tamanho da imagem
                if (!in_array($imagem->getMimeType(), ['image/jpeg', 'image/png', 'image/gif', 'image/webp']) || $imagem->getSize() > 2097152) {
                    $dados['msg'] = "Imagem inválida ou grande demais!!";
                    return view('post_form', $dados);
                }

                // salva a nova imagem na pasta
                $nomeImagem = $imagem->getRandomName();
                $imagem->move(FCPATH . 'uploads/receitas', $nomeImagem);

                $dadosPost['imagem'] = $nomeImagem;
            }




            if ($postModel->update($id, $dadosPost)) {
                // sucesso
                return redirect()->to('painel/posts');
            } else {
                // erro
                $dados['msg'] = "Erro ao salvar receita";
            }
        }

        return view('post_form', $dados);
    }




    public function excluir($id)
    {
        $postModel = model('PostModel');
        $postModel->delete($id);

        return redirect()->to('painel/posts');
    }



    public function visualizar($id) //recebe id e abre conteudo 
    {
        $postModel = model('PostModel');
        $dados['post'] = $postModel->find($id);

        if (!$dados['post']) { // se nao achar
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        return view('post_visualizar', $dados);
    }



    public function teste() // para exemplo, testa se banco esta funcionando e insercao
    {
        $postModel = new \App\Models\PostModel();

        $novoPost = [
            'titulo'   => "Bolo de Cenoura",
            'conteudo' => "Ingredientes: cenoura, ovos, açúcar e farinha. Modo de preparo: bata os ingredientes, coloque em uma forma e asse até dourar."
        ];

        if ($postModel->insert($novoPost)) {
            echo 'Receita salva com sucesso!';
        } else {
            echo 'Erro ao salvar receita <br />';
            print_r($postModel->errors());
        }
    }
}
