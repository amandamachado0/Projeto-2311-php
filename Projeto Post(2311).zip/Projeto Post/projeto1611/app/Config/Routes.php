<?php

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */

$routes->get('/', 'Home::index');

$routes->get('receitas', 'Home::receitas');

$routes->get('posts/teste', 'Posts::teste');

$routes->get('posts', 'Posts::index');
$routes->get('painel/posts', 'Posts::index');

$routes->match(['get', 'post'], 'posts/inserir', 'Posts::inserir');

$routes->match(['get', 'post'], 'posts/editar/(:num)', 'Posts::editar/$1');

$routes->get('posts/excluir/(:num)', 'Posts::excluir/$1');

$routes->get('posts/visualizar/(:num)', 'Posts::visualizar/$1');

