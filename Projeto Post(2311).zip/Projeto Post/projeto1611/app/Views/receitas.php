
<!DOCTYPE html>
<html lang="pt-br">
  <!-- TODAS AS RECEITAS CADASTRADAS quando clicar em descobrir receitas -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Todas as Receitas | Sabores da Casa</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #faf8f4;
            color: #49372c;
        }

        /* CABEÇALHO */

        header {
            background-color: #fff;
            padding: 23px 8%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #eee7df;
        }

        header h1 {
            color: #91452f;
            font-family: Georgia, serif;
            font-size: 30px;
            letter-spacing: -1px;
        }

        nav a {
            text-decoration: none;
            color: #66574c;
            margin-left: 30px;
            font-size: 14px;
            font-weight: bold;
            transition: 0.3s;
        }

        nav a:hover {
            color: #a34f32;
        }

        /* BANNER */

        .banner {
            background: linear-gradient(120deg, #f3e8dc, #e9d2bb);
            padding: 65px 10%;
            text-align: left;
        }

        .banner span {
            display: block;
            color: #a34f32;
            font-size: 14px;
            font-weight: bold;
            letter-spacing: 2px;
            margin-bottom: 18px;
        }

        .banner h2 {
            color: #713d29;
            font-family: Georgia, serif;
            font-size: 42px;
            margin-bottom: 15px;
        }

        .banner p {
            color: #654c3d;
            font-size: 16px;
            line-height: 1.8;
        }

        /* CONTEÚDO */
        .container {
            width: 85%;
            max-width: 1150px;
            margin: 65px auto;
        }

        .titulo-secao {
            margin-bottom: 35px;
        }

        .titulo-secao span {
            color: #a34f32;
            font-size: 12px;
            font-weight: bold;
            letter-spacing: 2px;
        }

        .titulo-secao h2 {
            font-family: Georgia, serif;
            font-size: 34px;
            color: #49372c;
            margin-top: 10px;
        }

        .titulo-secao p {
            color: #8a796d;
            font-size: 15px;
            margin-top: 10px;
        }

        /* CARDS */

        .receitas {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 28px;
        }

        .card {
            background-color: #fff;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 3px 15px rgba(73, 55, 44, 0.06);
            transition: 0.3s;
            border: 1px solid #f0e9e1;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 22px rgba(73, 55, 44, 0.12);
        }

        .card img {
            width: 100%;
            height: 230px;
            object-fit: cover;
            display: block;
        }

        .card-conteudo {
            padding: 22px;
        }

        .card h3 {
            color: #713d29;
            font-family: Georgia, serif;
            font-size: 23px;
            margin-bottom: 12px;
            line-height: 1.3;
        }

        .card p {
            color: #a34f32;
            font-size: 13px;
            line-height: 1.6;
            margin-bottom: 20px;
        }

        .card a {
            display: inline-block;
            color: #91452f;
            text-decoration: none;
            font-size: 14px;
            font-weight: bold;
            border-bottom: 1px solid #91452f;
            padding-bottom: 4px;
            transition: 0.3s;
        }

        .card a:hover {
            color: #713d29;
            border-color: #713d29;
        }

        /* QUANDO NÃO HÁ RECEITAS */
        .vazio {
            background-color: white;
            padding: 45px 25px;
            border-radius: 10px;
            text-align: center;
            grid-column: 1 / -1;
            border: 1px solid #eee7df;
        }

        .vazio h3 {
            font-family: Georgia, serif;
            color: #713d29;
            font-size: 23px;
            margin-bottom: 12px;
        }

        .vazio p {
            color: #83756b;
            font-size: 14px;
        }

        /* RODAPÉ */

        footer {
            background-color: #49372c;
            color: #fff;
            text-align: center;
            padding: 30px;
            margin-top: 80px;
        }

        footer p {
            font-size: 13px;
            color: #e9dcd1;
        }

    </style>
</head>

<body>

    <!-- CABEÇALHO -->
    <header>

        <h1>Sabores da Casa.</h1>

        <nav>
            <a href="<?= base_url('/') ?>">Início</a>
            <a href="<?= base_url('receitas') ?>">Receitas</a>
            <a href="<?= base_url('painel/posts') ?>">Painel</a>
        </nav>

    </header>

    <!-- BANNER -->
    <section class="banner">

        <span>DESCUBRA NOVOS SABORES</span>

        <h2>Todas as nossas receitas.</h2>

        <p>
            Explore nossa coleção completa de receitas,
            encontre novas inspirações e descubra seu próximo prato favorito.
        </p>

    </section>

    <!-- TODAS AS RECEITAS -->
    <main class="container" id="receitas">

        <div class="titulo-secao">

            <span>FEITAS COM CARINHO</span>

            <h2>Todas as receitas</h2>

            <p>
                Confira todas as receitas publicadas no Sabores da Casa.
            </p>

        </div>

        <div class="receitas">

            <?php if (!empty($posts)): ?>

                <?php foreach ($posts as $post): ?>

                    <div class="card">

                        <?php if (!empty($post->imagem)): ?>

                            <img
                                src="<?= base_url('uploads/receitas/' . $post->imagem) ?>"
                                alt="<?= esc($post->titulo) ?>"
                            >

                        <?php endif; ?>

                        <div class="card-conteudo">

                            <h3>
                                <?= esc($post->titulo) ?>
                            </h3>

                            <?php if (!empty($post->tempo_preparo)): ?>

                                <p>
                                    Tempo de preparo:
                                    <?= esc($post->tempo_preparo) ?>
                                </p>

                            <?php endif; ?>

                            <a href="<?= base_url('posts/visualizar/' . $post->id) ?>">
                                Ver receita →
                            </a>

                        </div>

                    </div>

                <?php endforeach; ?>

            <?php else: ?>

                <div class="vazio">

                    <h3>Nenhuma receita cadastrada ainda!</h3>

                    <p>
                        Em breve teremos novidades deliciosas por aqui.
                    </p>

                </div>

            <?php endif; ?>

        </div>

    </main>

  

    <footer>

        <p>
            Sabores da Casa - Todos os direitos reservados.
        </p>

    </footer>

</body>
</html>
