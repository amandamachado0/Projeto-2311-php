
<!DOCTYPE html>
<html lang="pt-BR">
<head>
     <!-- Visualizar receita ao clicar/ Post.php de Controller puxa -->

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($post->titulo) ?> | Sabores da Casa</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #faf6ef;
            color: #49372c;
            margin: 0;
            padding: 30px;
        }

        .container {
            background-color: white;
            max-width: 800px;
            margin: 40px auto;
            padding: 35px;
            border-radius: 12px;
            box-shadow: 0 3px 12px rgba(0,0,0,0.07);
        }

        h1 {
            color: #a34f32;
        }

        .conteudo {
            line-height: 1.8;
            white-space: pre-line;
        }

        a {
            display: inline-block;
            margin-top: 25px;
            background-color: #a34f32;
            color: white;
            padding: 10px 18px;
            border-radius: 6px;
            text-decoration: none;
        }
        .imagem-receita {
            width: 80%;
            max-height: 500px;
            object-fit: cover;
            border-radius: 12px;
            margin: 20px 0;
        }
    </style>
</head>

<body>
    <main class="container">
    <h1><?= esc($post->titulo) ?></h1>

    <div class="conteudo">
        <?= esc($post->conteudo) ?>
    </div>

    <?php if (!empty($post->imagem)): ?>
        <img src="<?= base_url('uploads/receitas/' . $post->imagem) ?>"
             alt="<?= esc($post->titulo) ?>"
             class="imagem-receita">
    <?php endif; ?>


    <a href="<?= base_url('/') ?>">Voltar para receitas</a>
</main>

</body>
</html>
