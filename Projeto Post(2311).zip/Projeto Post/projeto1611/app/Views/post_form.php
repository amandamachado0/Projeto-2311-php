
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciamento de Receitas - Cadastro</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #faf6ef;
            color: #49372c;
            margin: 0;
            padding: 30px;
        }

        .navbar {
            background-color: #49372c;
            padding: 18px 30px;
            border-radius: 10px;
        }

        .nav-container {
            max-width: 1100px;
            margin: auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .nav-brand {
            color: #faf6ef;
            font-size: 22px;
            font-weight: bold;
            text-decoration: none;
        }

        .nav-links {
            display: flex;
            gap: 25px;
            list-style: none;
            margin: 0;
            padding: 0;
        }

        .nav-links a {
            color: #faf6ef;
            text-decoration: none;
        }

        .nav-links a:hover,
        .nav-links .active {
            color: #e6b89c;
        }

        .container {
            max-width: 650px;
            margin: 40px auto;
        }

        .page-header {
            text-align: center;
            margin-bottom: 25px;
        }

        h1 {
            color: #a34f32;
        }

        .card {
            background-color: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(73, 55, 44, 0.08);
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }

        input, textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 6px;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
            color: #49372c;
        }

        input:focus, textarea:focus {
            outline: none;
            border-color: #a34f32;
        }

        textarea {
            min-height: 150px;
            resize: vertical;
        }

        .form-actions {
            text-align: center;
            margin-top: 25px;
        }

        button {
            padding: 12px 30px;
            background-color: #a34f32;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 15px;
        }

        button:hover {
            background-color: #843d28;
        }

        .voltar {
            text-align: center;
            margin-top: 25px;
        }

        .voltar a {
            color: #a34f32;
            text-decoration: none;
        }

        .voltar a:hover {
            text-decoration: underline;
        }

        .mensagem {
            text-align: center;
            color: #a34f32;
        }
    </style>
</head>

<body>

    <header class="navbar">
        <nav class="nav-container">
            <a href="<?= base_url('/') ?>" class="nav-brand">Sabores da Casa</a>

            <ul class="nav-links">
                <li><a href="<?= base_url('painel/posts') ?>">Lista de Receitas</a></li>
                <li><a href="<?= base_url('posts/inserir') ?>" class="active">Nova Receita</a></li>
            </ul>
        </nav>
    </header>

    <main class="container">

        <div class="page-header">
            <h1><?= isset($post) ? 'Editar Receita' : 'Cadastrar Receita' ?></h1> <!--clicando em editar receita ou cadastrar receita/ condicao ternáriac do php -->
        <!-- ? SE FOR VERDADEIRA / : caso contrario  -->

        </div>

        <div class="card form-card">

            <p class="mensagem"><?= esc($msg ?? '') ?></p>

            <form method="POST" enctype="multipart/form-data">

                <div class="form-group">
                    <label for="titulo">Nome da Receita</label>
                    <input
                        type="text"
                        id="titulo"
                        name="titulo"
                        value="<?= esc($post->titulo ?? '') ?>"
                        placeholder="Ex: Bolo de Cenoura"
                        required>
                </div>

                <div class="form-group">
                    <label for="tempo_preparo">Tempo de Preparo</label>
                    <input
                        type="text"
                        id="tempo_preparo"
                        name="tempo_preparo"
                        value="<?= esc($post->tempo_preparo ?? '') ?>"
                        placeholder="Ex: 50 minutos"
                        required>
                </div>

                <div class="form-group">
                    <label for="conteudo">Ingredientes e Modo de Preparo</label>
                    <textarea
                        id="conteudo"
                        name="conteudo"
                        placeholder="Informe os ingredientes e explique o modo de preparo..."
                        required><?= esc($post->conteudo ?? '') ?></textarea>
                </div>

                <div class="form-group">
                    <label for="imagem">Foto da Receita</label>
                    <input
                        type="file"
                        id="imagem"
                        name="imagem"
                        accept="image/*">
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Salvar Receita</button>
                </div>

            </form>

        </div>

        <div class="voltar">
            <a href="<?= base_url('painel/posts') ?>">Voltar ao painel</a>
        </div>

    </main>

</body>
</html>
